public enum ProjectStatus {
    PLANNING, IN_PROGRESS, COMPLETED    
}
