import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {
        String string = new String();
        List list = new ArrayList();

    }
}