public enum Country {
    China, EUA, Brasil, Russia, Canada, Unknown    
}
