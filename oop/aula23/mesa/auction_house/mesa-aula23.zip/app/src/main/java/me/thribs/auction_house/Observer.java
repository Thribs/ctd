public interface Observer {
    public void receiveNotification(Auction auction);
}